// Swift programming practice

enum Grade: String {
    case A, B, C, D, F

    static func calculate(marks: Double) -> Grade {
        switch marks {
        case 90...100: return .A
        case 80..<90: return .B
        case 70..<80: return .C
        case 40..<70: return .D
        default: return .F
        }
    }
}
struct Student {
    var name: String
    var rollNumber: Int
    var marks: Double

    var grade: Grade {
        return Grade.calculate(marks: marks)
    }
}
class School {
    var students: [Student] = []

    func addStudent(_ student: Student) {
        students.append(student)
    }

    func printReport() {
        let sortedStudents = students.sorted { $0.marks > $1.marks }
        for student in sortedStudents {
            print("Name: \(student.name), Roll: \(student.rollNumber), Marks: \(student.marks), Grade: \(student.grade.rawValue)")
        }
    }
}
let school = School()
school.addStudent(Student(name: "Arun", rollNumber: 101, marks: 85))
school.addStudent(Student(name: "Priya", rollNumber: 102, marks: 95))
school.addStudent(Student(name: "Bala", rollNumber: 103, marks: 72))
school.printReport()
