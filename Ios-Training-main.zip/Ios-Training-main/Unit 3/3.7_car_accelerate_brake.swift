// Swift programming practice

class Car {
    var brand: String
    var speed: Int

    init(brand: String, speed: Int = 0) {
        self.brand = brand
        self.speed = speed
    }

    func accelerate() {
        speed += 10
        print("Speed: \(speed)")
    }

    func brake() {
        speed = max(0, speed - 10)
        print("Speed: \(speed)")
    }
}
let car = Car(brand: "Toyota")
car.accelerate()
car.brake()
