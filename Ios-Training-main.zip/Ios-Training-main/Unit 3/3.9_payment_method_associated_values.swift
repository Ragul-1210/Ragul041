// Swift programming practice

enum PaymentMethod {
    case cash
    case card(number: String)
    case upi(id: String)
}

func processPayment(_ method: PaymentMethod) {
    switch method {
    case .cash:
        print("Payment using cash")
    case .card(let number):
        print("Payment using card: \(number)")
    case .upi(let id):
        print("Payment using UPI: \(id)")
    }
}
processPayment(.cash)
processPayment(.card(number: "1234"))
processPayment(.upi(id: "user@upi"))
