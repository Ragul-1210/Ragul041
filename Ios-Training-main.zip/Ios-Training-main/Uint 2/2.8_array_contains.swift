// Swift programming practice

let numbers = [10, 20, 30, 40, 50]
let value = 30
print(numbers.contains(value))
