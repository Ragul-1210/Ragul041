// Swift programming practice

let number = -5
if number > 0 {
    print("Positive")
} else if number < 0 {
    print("Negative")
} else {
    print("Zero")
}
