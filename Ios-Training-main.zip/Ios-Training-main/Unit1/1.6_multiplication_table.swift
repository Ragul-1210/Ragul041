// Swift programming practice

let number = 5
for i in 1...10 {
    print("\(number) x \(i) = \(number * i)")
}
